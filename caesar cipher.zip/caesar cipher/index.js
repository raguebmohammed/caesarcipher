document.getElementById("encryptButton").onclick = function () {
    let str = document.getElementById("textToEncryptInput").value;
    let key = parseInt(document.getElementById("encryptionKey").value);
    function caesarCipher(str, key) {
        let alphabet = "abcdefghijklmnopqrstuvwxyz";
        let ALPHABET = alphabet.toUpperCase();
        let result = "";
        for (let i = 0; i < str.length; i++) {
          let char = str[i];
          let index = alphabet.indexOf(char);
          if (index >= 0) {
            result += alphabet[(index + key) % 26];
          } else {
            index = ALPHABET.indexOf(char);
            if (index >= 0) {
              result += ALPHABET[(index + key) % 26];
            } else {
              result += char;
            }
          }
        }
        return result;
    }
        let encrypted = caesarCipher(str, key);
        document.getElementById("encryptedText").innerHTML = "the encryption of "+str+" using the key "+key+" is "+ encrypted;
}

document.getElementById("decryptButton").onclick = function () {
    let str = document.getElementById("textToDecryptInput").value;
    let key = parseInt(document.getElementById("decryptionKey").value);
    function caesarCipherDecryption(str, key) {
      let decryptedMessage = "";
      for (let i = 0; i < str.length; i++) {
        let currentChar = str[i];
        if (currentChar.match(/[a-z]/i)) {
          let charCode = str.charCodeAt(i);
          if ((charCode >= 65) && (charCode <= 90)) {
            charCode -= key;
            if (charCode < 65) {
              charCode = 90 - (64 - charCode);
            }
          } else if ((charCode >= 97) && (charCode <= 122)) {
            charCode -= key;
            if (charCode < 97) {
              charCode = 122 - (96 - charCode);
            }
          }
          currentChar = String.fromCharCode(charCode);
        }
        decryptedMessage += currentChar;
      }
      return decryptedMessage;
    }
    let decrypted = caesarCipherDecryption(str, key);
    document.getElementById("decryptedText").innerHTML = "the decryption of " + str +" using the key "+ key +" is "+ decrypted;
}